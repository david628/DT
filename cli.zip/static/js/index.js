
console.log(path);