'use strict';
var express = require('express');
// var bodyParser = require('body-parser');
// var partials = require('express-partials');
var ejs = require('ejs');
var app = express();

// var mw = require('./middleware');
// var multer = require('multer');

// var log = require('../utils/log');
var path = require('path');
// var fs = require('xfs');
var open = require('open');
// var i18n = require('../i18n_json');
var router = require('./router')

module.exports = (option) => {
    let { source, port, view, staticPath } = option;

    app.set('views', view);
    app.engine('.html', ejs.renderFile);
    app.set('view cache', false);
    app.set('view engine', 'html');

    //partials.register('.html', ejs.render);
    app.set('x-powered-by', false);

    //app.use(partials());
    //app.use(bodyParser.json({ strict: true }));
    //app.use(bodyParser.urlencoded({ extended: true }));

    // app.use(multer({limits: {
    //   fileSize: 3*1024*1024,
    //   files: 1
    // }}).single('file'));

    app.use(router(express.Router(), source));
    app.use('/static', express.static(staticPath));

    //app.use('/__static__', mw.cubeAdmin(option.root, option.config));
    //app.use('/', mw.cubeUser(source))

    app.use(function (req, res) {
        res.status(404).end('Not Found');
    });

    app.listen(port, function (err) {
        if (err) {
            log.err(err)
            return
        }
    }).on('error', function(err) {
        console.log.info(`Error: `, err);
    });

    open(`http://localhost:${port}`);

//   let source = option.source;
//   let port = option.port;

//   try {
//     app.engine('.html', ejs.renderFile);
//     app.set('views', option.view);
//     app.set('view cache', false);
//     app.set('view engine', 'html');
//     partials.register('.html', ejs.render);
//     app.set('x-powered-by', false);

//     app.use(partials());
//     app.use(bodyParser.json({ strict: true }));
//     app.use(bodyParser.urlencoded({ extended: true }));

//     app.use(multer({limits: {
//       fileSize: 3*1024*1024,
//       files: 1
//     }}).single('file'));

//     var router = require('./router')(ex.Router(), source);
//     app.use(router);

//     app.use('/__static__', mw.cubeAdmin(option.root, option.config));
//     app.use('/', mw.cubeUser(source))

//     app.use(function (req, res) {
//       res.status(404).end('Not Found');
//     });

//     app.listen(port, function (err) {
//       if (err) {
//         log.err(err)
//         return
//       }
//     }).on('error', function(err) { 
//       log.info(`${i18n.get('preview.servicePortConflict')} http://localhost:${port}/${option.page || ''}`)
//     });

//     if (!option.silent) {
//       open(`http://localhost:${port}/${option.page || ''}`);
//       log.info(i18n.get('preview.serviceStart', {port: `${port}/${option.page || ''}`}));
//     }
//   } catch (e) {
//     log.err(e.stack || e);
//   }
}