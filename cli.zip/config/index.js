'use strict';

var path = require('path');
module.exports = {
  env: 'dev',
  debug: true,
  root: path.join(__dirname, '../'),
  port: 8989,
  cacheDir: 'tmp_cache',
};