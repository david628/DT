export default class Chart {
    constructor(props) {
        this.parent = null;
        this.children = [];
        Object.assign(this, props);
    }
    refresh() {

    }
    load() {

    }
    resize() {

    }
}
