class Color {
    constructor(props) {
        this.sprefix = 'dwrui';
        Object.assign(this, props);
        this.template = `
            <div class="${ this.sprefix }-color-picker">
                <div class="${ this.sprefix }-color-picker-header" style="height: 36px;">
                    <div class="${ this.sprefix }-color-picker-list" style="width: 100%;height: 100%;padding: 8px 10px;box-sizing: border-box;">
                        <div class="${ this.sprefix }-color-picker-item"></div>
                        <div class="${ this.sprefix }-color-picker-item" style="background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAMAAABg3Am1AAABO1BMVEVHcExjsb/uTqzhymrlZp7Rjox7w57FwYJNm+aw6VX+m0/6Soe611x2urJkoNbks2r0aG2Du6v/MJhIm+r/MZj/MZj/QWj/c03+m1D/TlCSxZTktWH7zFSg3XBxr7y/u4A7kvo5lPn/Kqz/N4Rnodb/gk3+sU//dE7/0VL/J8X/Jb6FyZJ6psNaqs2z61LAzmP6Mb/Sl4Lgd5OXsar9pFBImez/S01vua//OX7+jk7+Ykz+bkz/LaH/V0z5ML3/QGn/JMH+eU3/L5z/Rlj/PXOR04Cyu5P9uU/+g03/JrhZqs2j4GeFyo+Cqrz8y1L20Fe35lM8lfX/M43/KK//QmBvpMtRo9qRsK70P7TBymLXj4bLrHX9w1DUxnWitqHcf4/tz2DQnX7+OYeb2nPgdJXGumzsV6H5sVH/MZea7IfDAAAANHRSTlMA/fz9/iH9/v/+/jr9Nv02VFTz2dmB0MPZ7IGB0Mv9w76Bvr7Zgb7YVFTYx77H2dnH2MfYBQ7XUQAAAelJREFUSMft1VlbgkAUBuBUlCnFpX192ve9RNxAU3Oh0BYETcUlxf7/L+gMWHoxqPf1eXveM2eAGWdm/vN3417aX5yfX9xbck9V7l/OhMNvb6n4+3vh7HRiuXNZTvyCZFK4cU6YZk2WE4kRINjHzuUOhdLpBCzRwaAAoGIfJ5xrGMBMmR9Qqdh1ynqqlSjPA8G76KTihYIAC1BU987y+URNkB4COwZNvwU4jsVMIsvhMAAYSIfyj49bcr3vIWYIPFTGBNC/CaDtI4LD/AMEDB+Cob7igqDj8natVtsgbzmfzxsAhAEqVBe6A+htE8FqBGKiaCj9ldIp3L3Xq1ar10QwFzEDJMbzHb3bbJvlVY+HCIJz+DdIEKo8Lz+ZJY8UHEnf8zQ7zBURHPX7/RykXi+WGnRZ5FyPj5+fTzhbRLCRG5QXSy06qyAb9/w8IOvkF1c3ikstR4PWVIQUkTMIIIb8qjeLRQwcDppWJcQqCse5XJhsWXxLJ9C95YD+WU0CgJBoM0nA6nPdxKBB05omlRHLIlE0wLn1AcLt6WxWVcsYsIpow2uMOda+xgh4hV1gwIw71D4o1zRVKnsBvMKDEm3MhGtmG4A0BJfOiTdT4F6VJK+XBcAuBKa6+5j1iwMvWtjZZf7/Nv5wvgHGFpB5+rlLRwAAAABJRU5ErkJggg==) no-repeat;background-size: 100% 100%;"></div>
                        <div class="${ this.sprefix }-color-picker-item"></div>
                        <div class="${ this.sprefix }-color-picker-item"></div>
                    </div>
                </div>
                <div class="${ this.sprefix }-color-picker-center">
                    <div class="${ this.sprefix }-color-picker-center-inner">
                        <div></div>
                        <div class="${ this.sprefix }-color-picker-panel">
                            <div class="${ this.sprefix }-color-picker-hue">
                                <div class="${ this.sprefix }-color-picker-saturation">
                                    <div class="${ this.sprefix }-color-picker-brightness"></div>
                                </div>
                            </div>
                            <div class="${ this.sprefix }-color-picker-pointer"></div>
                        </div>
                        <div class="${ this.sprefix }-color-picker-fixed">
                            <div class="${ this.sprefix }-color-picker-left">
                                <div class="dwrui-color-picker-area-slider-bg">
                                    <input class="dwrui-color-picker-range dwrui-color-picker-area-slider" type="range" min="0" max="360" value="360"/>
                                </div>
                                <div class="dwrui-color-picker-alpha-slider-bg">
                                    <input class="dwrui-color-picker-range dwrui-color-picker-alpha-slider" type="range" min="0" max="100" value="100"/>
                                </div>
                            </div>
                            <div class="${ this.sprefix }-color-picker-right">
                                <div class="${ this.sprefix }-color-picker-preview-bg">
                                    <div class="${ this.sprefix }-color-picker-preview"></div>
                                </div>
                            </div>
                        </div>
                        <div style="overflow: hidden;margin-top: 5px;">
                            <div style="float: left;width: 30%;padding-left: 15px;position: relative;box-sizing: border-box;">
                                <span style="position: absolute;top: 0;left: 0;line-height: 26px;">#</span>
                                <input class="dwrui-color-picker-input dwrui-color-picker-input-hex" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>
                                <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">HEX</div>
                            </div>
                            <div style="float: left;width: 70%;box-sizing: border-box;">
                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">
                                    <input class="dwrui-color-picker-input dwrui-color-picker-rgba-r" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>
                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">R</div>
                                </div>
                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">
                                    <input class="dwrui-color-picker-input dwrui-color-picker-rgba-g" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>
                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">G</div>
                                </div>
                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">
                                    <input class="dwrui-color-picker-input dwrui-color-picker-rgba-b" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>
                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">B</div>
                                </div>
                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">
                                    <input class="dwrui-color-picker-input dwrui-color-picker-rgba-a" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>
                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">A</div>
                                </div>
                            </div>
                        </div>
<!--                        <div style="overflow: hidden;margin-top: 5px;">-->
<!--                            <div style="float: left;width: 30%;box-sizing: border-box;">&nbsp;</div>-->
<!--                            <div style="float: left;width: 70%;box-sizing: border-box;">-->
<!--                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">-->
<!--                                    <input class="dwrui-color-picker-input dwrui-color-picker-hsla-h" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>-->
<!--                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">H</div>-->
<!--                                </div>-->
<!--                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">-->
<!--                                    <input class="dwrui-color-picker-input dwrui-color-picker-hsla-s" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>-->
<!--                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">S</div>-->
<!--                                </div>-->
<!--                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">-->
<!--                                    <input class="dwrui-color-picker-input dwrui-color-picker-hsla-l" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>-->
<!--                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">L</div>-->
<!--                                </div>-->
<!--                                <div style="float: left;width: 25%;padding-left: 5px;box-sizing: border-box;">-->
<!--                                    <input class="dwrui-color-picker-input dwrui-color-picker-hsla-a" type="text" style="width: 100%;padding: 0 5px;outline: none;box-sizing: border-box;"/>-->
<!--                                    <div class="dwrui-color-picker-label" style="width: 100%;font-size: 12px;text-align: center;">A</div>-->
<!--                                </div>-->
<!--                            </div>-->
<!--                        </div>-->
                    </div>
                </div>
                <div class="${ this.sprefix }-color-picker-footer">
                    <div class="${ this.sprefix }-color-picker-global">
                        <input class="${ this.sprefix }-color-picker-chk" type="checkbox"/>
                        <div class="${ this.sprefix }-color-picker-arrow-wrap">
                            <span class="${ this.sprefix }-color-picker-arrow"></span>
                            <span style="font-size: 12px;">Global Colors</span>
                        </div>
                        <div class="${ this.sprefix }-color-picker-list">
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item-add">+</div>
                        </div>
                    </div>
                    <div class="${ this.sprefix }-color-picker-recent">
                        <input class="${ this.sprefix }-color-picker-chk" type="checkbox"/>
                        <div class="${ this.sprefix }-color-picker-arrow-wrap">
                            <span class="${ this.sprefix }-color-picker-arrow"></span>
                            <span style="font-size: 12px;">Recent Colors</span>
                        </div>
                        <div class="${ this.sprefix }-color-picker-list">
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                            <div class="${ this.sprefix }-color-picker-item"></div>
                        </div>
                    </div>
                </div>
            </div>`;
        //this.el.className = 'dwrui-color-picker';
        this.el.innerHTML = this.template;
        this.panel = this.el.querySelector(`.${ this.sprefix }-color-picker-panel`);
        this.pointer = this.panel.querySelector(`.${ this.sprefix }-color-picker-pointer`);
        this.preview = this.el.querySelector(`.${this.sprefix}-color-picker-preview`);
        this.hexInput = this.el.querySelector(`.${this.sprefix}-color-picker-input-hex`);
        this.rInput = this.el.querySelector(`.${this.sprefix}-color-picker-rgba-r`);
        this.gInput = this.el.querySelector(`.${this.sprefix}-color-picker-rgba-g`);
        this.bInput = this.el.querySelector(`.${this.sprefix}-color-picker-rgba-b`);
        this.aInput = this.el.querySelector(`.${this.sprefix}-color-picker-rgba-a`);

        // this.hInput = this.el.querySelector(`.${this.sprefix}-color-picker-hsla-h`);
        // this.sInput = this.el.querySelector(`.${this.sprefix}-color-picker-hsla-s`);
        // this.lInput = this.el.querySelector(`.${this.sprefix}-color-picker-hsla-l`);
        // this.laInput = this.el.querySelector(`.${this.sprefix}-color-picker-hsla-a`);

        this.hue = this.el.querySelector(`.${this.sprefix}-color-picker-hue`);
        this.areaInput = this.el.querySelector(`.${this.sprefix}-color-picker-area-slider`);
        this.alphaInput = this.el.querySelector(`.${this.sprefix}-color-picker-alpha-slider`);

        this.areaInput.onchange = (e) => {
            this.hsv.h = this.areaInput.value;
            this.update();
        };
        this.alphaInput.onchange = (e) => {
            this.rgba.a = this.alphaInput.value / 100;
            this.update();
        };

        this.rWidth = this.panel.offsetWidth;
        this.rHeight = this.panel.offsetHeight;

        this.initEvent();
        let v = '#e3f';
        let hex = v.indexOf("#") > -1 ? v.slice(1) : v;
        let rgba = this.hexToRgba(hex);
        this.setValue(rgba);
    }
    setValue(v) {
        //let hex = v.indexOf("#") > -1 ? v.slice(1) : v;
        //this.hexInput.value = hex;
        //this.rgba = this.hexToRgba(hex);
        this.rgba = v;


        this.hsv = this.rgbToHsv(this.rgba);
        console.log(this.rgba);
        console.log(this.hsv);

        let left = Math.floor(this.hsv.s / 100 * this.rWidth);
        let top = Math.floor((1 - this.hsv.v / 100) * this.rHeight);
        this.pointer.style.left = left + 'px';
        this.pointer.style.top = top + 'px';

        this.areaInput.value = this.hsv.h;
        this.alphaInput.value = this.rgba.a * 100;

        this.update();
    }
    update() {
        this.hexInput.value = this.rgbaToHex(this.rgba);
        this.rInput.value = this.rgba.r;
        this.gInput.value = this.rgba.g;
        this.bInput.value = this.rgba.b;
        this.aInput.value = this.rgba.a;

        let hsv = this.hsv;

        let left = parseFloat(this.pointer.style.left, 10);
        let top = parseFloat(this.pointer.style.top, 10);

        let h = this.hsv.h;
        let hueColor = this.hsvToRgb(h);
        this.hue.style.backgroundColor = `rgb(${ hueColor.r },${ hueColor.g },${ hueColor.b })`;

        let s = parseFloat(left / this.rWidth, 10);
        let v = parseFloat((this.rHeight - top) / this.rHeight, 10);
        let rbg = this.hsvToRgb(h, s, v);
        Object.assign(this.rgba, rbg);
        let startColor = `rgba(${ this.rgba.r },${ this.rgba.g },${ this.rgba.b },0)`;
        let endColor = `rgba(${ this.rgba.r },${ this.rgba.g },${ this.rgba.b })`;
        this.alphaInput.style.setProperty("--start-value", startColor);
        this.alphaInput.style.setProperty("--end-value", endColor);

        this.preview.style.backgroundColor = `rgba(${ this.rgba.r }, ${ this.rgba.g }, ${ this.rgba.b }, ${ this.rgba.a === undefined ? 1 : this.rgba.a })`;
    }
    hsvToRgb(ah, as = 1, av = 1) {
        let h = ah / 60 % 6, s = as, v = av;
        if(as > 1) {
            s = as / 100;
        }
        if(av > 1) {
            v = av / 100;
        }
        let i = Math.floor(h),
            f = h - i,
            p = v * (1 - s),
            q = v * (1 - f * s),
            t = v * (1 - (1 - f) * s),
            mod = i % 6,
            r = [v, q, p, p, t, v][mod],
            g = [t, v, v, q, p, p][mod],
            b = [p, p, t, v, v, q][mod];
        return {
            r: Math.floor(r * 255),
            g: Math.floor(g * 255),
            b: Math.floor(b * 255)
        };
    }
    rgbToHsv(rgb) {
        let r = rgb.r / 255;
        let g = rgb.g / 255;
        let b = rgb.b / 255;
        let max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, v = max;
        let d = max - min;
        s = max === 0 ? 0 : d / max;
        if(max == min) {
            h = 0;
        } else {
            switch (max) {
                case r:
                    h = (g - b) / d + (g < b ? 6 : 0);
                    break;
                case g:
                    h = (b - r) / d + 2;
                    break;
                case b:
                    h = (r - g) / d + 4;
                    break;
            }
            h /= 6;
        }
        return {
            h: Math.floor(h * 360),
            s: Math.floor(s * 100),
            v: Math.floor(v * 100)
        };
    }
    hexToRgba(HEX) {
        let hex = HEX.indexOf("#") > -1 ? HEX.slice(1) : HEX;
        if(hex.length === 3) {
            hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
        }
        return {
            r: parseInt(hex.slice(0, 2), 16) || 0,
            g: parseInt(hex.slice(2, 4), 16) || 0,
            b: parseInt(hex.slice(4, 6), 16) || 0,
            a: (parseInt(hex.slice(6, 8), 16) || 255) / 255
        };
    }
    rgbaToHex(rgba) {
        return (
            (rgba.r < 16 ? '0' : '') + rgba.r.toString(16) +
            (rgba.g < 16 ? '0' : '') + rgba.g.toString(16) +
            (rgba.b < 16 ? '0' : '') + rgba.b.toString(16)
        ).toUpperCase();
    }
    // hexToRgb(hex) {
    //     let HEX = hex.split('');
    //     return {
    //         r: +('0x' + HEX[0] + HEX[HEX[3] ? 1 : 0]) / 255,
    //         g: +('0x' + HEX[HEX[3] ? 2 : 1] + (HEX[3] || HEX[1])) / 255,
    //         b: +('0x' + (HEX[4] || HEX[2]) + (HEX[5] || HEX[2])) / 255
    //     };
    // }
    // RGB2HEX(RGB) {
    //     return (
    //         (RGB.r < 16 ? '0' : '') + RGB.r.toString(16) +
    //         (RGB.g < 16 ? '0' : '') + RGB.g.toString(16) +
    //         (RGB.b < 16 ? '0' : '') + RGB.b.toString(16)
    //     ).toUpperCase();
    // }
    // hue2RGB(hue) {
    //     var _Math = _math,
    //         h = hue * 6,
    //         mod = ~~h % 6, // Math.floor(h) -> faster in most browsers
    //         i = h === 6 ? 0 : (h - mod);
    //
    //     return {
    //         r: _Math.round([1, 1 - i, 0, 0, i, 1][mod] * 255),
    //         g: _Math.round([i, 1, 1, 1 - i, 0, 0][mod] * 255),
    //         b: _Math.round([0, 0, i, 1, 1, 1 - i][mod] * 255)
    //     };
    // }
    initEvent() {
        this.isMove = false;
        this.onMouseMove = e => {
            this.stopEvent(e);
            if(this.isMove) {
                this.setPos({
                    x: e.pageX || e.clientX,
                    y: e.pageY || e.clientY
                });
            }
        }
        this.onMouseUp = e => {
            this.stopEvent(e);
            this.isMove = false;
            document.removeEventListener('mousemove', this.onMouseMove);
            document.removeEventListener('mouseup', this.onMouseUp);
        }
        this.onMouseDown = e => {
            this.stopEvent(e);
            this.isMove = true;
            this.setPos({
                x: e.pageX || e.clientX,
                y: e.pageY || e.clientY
            });
            document.addEventListener('mousemove', this.onMouseMove);
            document.addEventListener('mouseup', this.onMouseUp);
        }
        this.panel.addEventListener('mousedown', this.onMouseDown);
    }
    setPos(pos) {
        let rect = this.panel.getBoundingClientRect();
        let left = pos.x - rect.left - (window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0);
        let top = pos.y - rect.top - (window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0);
        left = Math.max(0, left);
        left = Math.min(left, this.rWidth);
        top = Math.max(0, top);
        top = Math.min(top, this.rHeight);
        this.pointer.style.left = left + 'px';
        this.pointer.style.top = top + 'px';

        this.update();
        //this.preview.style.background = `rgba(${ this.rgba.r }, ${ this.rgba.g }, ${ this.rgba.b }, ${ this.rgba.a || 1 })`;

        //console.log(this.hsb);
        // const hue = this.hsb.h;
        // const saturation = left / rect.width;
        // const bright = (rect.height - top) / rect.height;
        // let hsb = {
        //   h: this.hsb.h,
        //   s: left / rect.width * 100,
        //   b: 100 - top / rect.height * 100
        // }
        // let hex = this.hsbToHex(hsb)
        // let rgba = this.hexToRgb(hex);
        // this.hsb = this.rgbToHsb(rgba);
        //this.setValue(rgba);
    }

    // toHexString(value, flag) {
    //     let rgba = this.toRgba(value);
    //     return this.rgbaToHexString(rgba, flag);
    // }
    // toRgba(value) {
    //     let rgba;
    //     if (value.startsWith("rgb")) {
    //         let cs = value.split('(')[1].split(')')[0].split(',');
    //         rgba = {
    //             r: parseInt(cs[0], 10),
    //             g: parseInt(cs[1], 10),
    //             b: parseInt(cs[2], 10),
    //             a: cs.length > 3 ? parseFloat(cs[3], 10) : 1
    //         };
    //         return rgba;
    //     }
    //     rgba = this.hexToRgba(value);
    //     return rgba;
    // }
    // rgbaToHexString(rgba, flag) {
    //     return (flag ? '#' : '') + `${ this.toHex2String(rgba.r) }${ this.toHex2String(rgba.g) }${ this.toHex2String(rgba.b) }`;
    // }
    // toHex2String(value) {
    //     return parseInt(value, 10).toString(16).padStart(2, '0').toUpperCase();
    // }
    // hexToRgba(ohexColor) {
    //     let hexColor = ohexColor.replace(/ /g, '');
    //     if(hexColor.startsWith('#')) {
    //         hexColor = hexColor.substr(1, 6);
    //     }
    //     if(hexColor == '') {
    //         hexColor = '#FFFFFF';
    //     } else if(hexColor.length < 3) {
    //         hexColor = hexColor.padEnd(3, 'F');
    //     }
    //     let r, g, b, a = 255;
    //     if(hexColor.length < 6) {
    //         r = parseInt(`0x${ hexColor[0] }${ hexColor[0] }`, 10);
    //         g = parseInt(`0x${ hexColor[1] }${ hexColor[1] }`, 10);
    //         b = parseInt(`0x${ hexColor[2] }${ hexColor[2] }`, 10);
    //     } else {
    //         r = parseInt(`0x${ hexColor[0] }${ hexColor[1] }`, 10);
    //         g = parseInt(`0x${ hexColor[2] }${ hexColor[3] }`, 10);
    //         b = parseInt(`0x${ hexColor[4] }${ hexColor[5] }`, 10);
    //     }
    //     if(hexColor.length > 7) {
    //         a = parseInt(`0x${ hexColor[6] }${ hexColor[7] }`);
    //         if(isNaN(a)) {
    //             a = 255;
    //         }
    //     }
    //     if(isNaN(r)) {
    //         r = 255;
    //     }
    //     if(isNaN(g)) {
    //         g = 255;
    //     }
    //     if(isNaN(b)) {
    //         b = 255;
    //     }
    //     return {
    //         r,
    //         g,
    //         b,
    //         a: a / 255
    //     };
    // }
    // getColorObject(color) {
    //     let type, colors, angleValue = 180, shape = "ellipse";
    //     if (typeof color == 'string') {
    //         if (color.startsWith('{')) {
    //             let obj = JSON.parse(color);
    //             if (obj.color) {
    //                 color = obj.color;
    //             } else {
    //                 return this.getEColorObject(obj.ecolor);
    //             }
    //         }
    //         if (color.startsWith('linear-gradient') || color.startsWith('radial-gradient')) {
    //             let obj = this.getGradientColor(color);
    //             colors = obj.colors;
    //             type = obj.type;
    //             angleValue = obj.angleValue;
    //             shape = obj.shape;
    //         } else if(color.startsWith('#') || color.startsWith('rgb') || color.startsWith('RGB')) {
    //             type = 1;
    //         } else {
    //             return;
    //         }
    //     } else if (typeof color == 'object') {
    //         let obj = color;
    //         if (obj.color) {
    //             color = obj.color;
    //         } else {
    //             return this.getEColorObject(obj.ecolor);
    //         }
    //     }
    //     return {
    //         type,
    //         colors,
    //         angleValue,
    //         color,
    //         shape
    //     };
    // }
    stopEvent(e) {
        this.stopPropagation(e);
        this.preventDefault(e);
    }
    preventDefault(e) {
        if(e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
    }
    stopPropagation(e) {
        if (e.type == 'mousedown') {
            return true;
        }
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
    }
}




var c = new Color({
  el: document.getElementById('id-test')
});
