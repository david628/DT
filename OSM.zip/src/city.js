import * as THREE from 'three';
import Geo from './geo';
import { LineMaterial } from './LineMaterial';
import { LineGeometry } from './LineGeometry';
//let EffectComposer = require('three-effectcomposer')(THREE);
//THREE.EffectComposer = EffectComposer;





class City {
    constructor(props) {
        this.Geo = Geo;
        this.country = {};
        Object.assign(this, props);
        this.animate = this.animate.bind(this);
        this.init();
    }
    init() {
        this.el = document.getElementById(this.el);
        let w = this.el.offsetWidth,
            h = this.el.offsetHeight;
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, w / h, 1, 1000);
        this.camera.position.set(0, 0, 10);
        this.camera.position.z = 100;

        this.renderer = new THREE.WebGLRenderer();
        this.renderer.setSize(w, h);
        this.el.appendChild(this.renderer.domElement);

        this.scene.add(new THREE.AxesHelper(300));

        let point = new THREE.PointLight(0xffffff);
        point.position.set(400, 200, 300); //点光源位置
        this.scene.add(point); //点光源添加到场景中

        //this.rotating = new THREE.Object3D();
        //this.scene.add(this.rotating);

        this.creat3DMap();

    }
    creat3DMap() {
        var Geo = this.Geo;
        var count = 0;
        var options = {
            depth: 100, // 定义图形拉伸的深度，默认100
            steps: 0, // 拉伸面方向分为多少级，默认为1
            bevelEnabled: true, // 表示是否有斜角，默认为true
            bevelThickness: 0, // 斜角的深度，默认为6
            bevelSize: 0, // 表示斜角的高度，高度会叠加到正常高度
            bebelSegments: 0, // 斜角的分段数，分段数越高越平滑，默认为1
            curveSegments: 0 // 拉伸体沿深度方向分为多少段，默认为1
        }
        // var material2 = new THREE.MeshPhongMaterial({
        //   color: 0x000000,
        //   side: THREE.DoubleSide
        // });
        var material2 = new THREE.MeshBasicMaterial({
            color: 0x00173A
        });
        var lineMaterial = new THREE.MeshBasicMaterial({
            color: 0x0080F5
        });
        //var baseLine = new THREE.Geometry();
        for (var i = 0; i < Geo.features.length; i++) {
            if (Geo.features[i].properties.name === 'Antarctica') {
                continue;
            }
            //var color = new THREE.Color(0xffffff).setHSL(Math.floor(Math.random() * 30 + 30) / 30, 0.6, 0.6);
            var color = new THREE.Color(0x00173A);
            var base = new THREE.Geometry();
            var gm = Geo.features[i].geometry;
            var coordinates = gm.coordinates;

            if (gm.type == 'Polygon') {
                var path = [], v;
                for (var a = 0; a < coordinates.length; a++) {
                    for (var b = 0; b < coordinates[a].length; b++) {
                        var v = this.createVector3(this.type, coordinates[a][b][0], coordinates[a][b][1]);
                        path.push(v);
                        count++;
                    }
                }
                //this.toPath(path, base, this.country[Geo.features[i].properties.name]);
                var shape = new THREE.Shape(path);
                var lineGeometry = new THREE.ShapeGeometry(shape);
                var geometry = new THREE.ExtrudeGeometry(shape, options);
                //base.merge(geometry);
                var mesh = new THREE.Mesh(geometry, [new THREE.MeshBasicMaterial({ color: color }), material2]);
                this.scene.add(mesh);
                var line = new THREE.Line(lineGeometry, lineMaterial);
                line.position.z = this.depth + 1;
                this.scene.add(line);
            } else if (gm.type == 'MultiPolygon') {
                for (var a = 0; a < coordinates.length; a++) {
                    var path = [], v;
                    for (var b = 0; b < coordinates[a].length; b++) {
                        for (var c = 0; c < coordinates[a][b].length; c++) {
                            var v = this.createVector3(this.type, coordinates[a][b][c][0], coordinates[a][b][c][1]);
                            path.push(v);
                            count++;
                        }
                    }
                    //this.toPath(path, base, this.country[Geo.features[i].properties.name]);
                    var shape = new THREE.Shape(path);
                    var lineGeometry = new THREE.ShapeGeometry(shape);
                    var geometry = new THREE.ExtrudeGeometry(shape, options);
                    //base.merge(geometry);
                    var mesh = new THREE.Mesh(geometry, [new THREE.MeshBasicMaterial({ color: color }), material2]);
                    this.scene.add(mesh);
                    var line = new THREE.Line(lineGeometry, lineMaterial);
                    line.position.z = this.depth + 1;
                    this.scene.add(line);
                }
            }
        }
    }
    createVector3(type, lon, lat) {
        return new THREE.Vector3(
            (lon / 180) * this.radius * 2,
            (lat / 180) * this.radius * 2
        );

    }
    animate() {
        requestAnimationFrame(this.animate);
        this.renderer.render(this.scene, this.camera);
    }

}

var cy = new City({
    el: 'id-test'
});
cy.animate();
// var el = document.getElementById('id-test');
// var w = el.offsetWidth;
// var h = el.offsetHeight;
// var scene = new THREE.Scene();
// var camera = new THREE.PerspectiveCamera( 75, w/h, 1, 1000 );
// //camera.position.set(-40, 0, 60);

// var renderer = new THREE.WebGLRenderer();
// renderer.setSize( w, h );
// el.appendChild( renderer.domElement );

// var geometry = new THREE.BoxGeometry( 1, 1, 1 );
// var material = new THREE.MeshBasicMaterial( { color: 0x00ff00 } );
// var cube = new THREE.Mesh( geometry, material );
// scene.add( cube );

// camera.position.z = 5;

// var render = function () {
//     requestAnimationFrame( render );

//     cube.rotation.x += 0.1;
//     cube.rotation.y += 0.1;

//     renderer.render(scene, camera);
// };

// render();