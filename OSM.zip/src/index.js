import './assets/css/index.less';
import Ruler from './components/ui/Ruler';
import Selection from './components/ui/Selection';
import DragDrop from './components/ui/DragDrop';
import Resizable from './components/ui/Resizable';
let editWrap = document.getElementById('id-edit-wrap');
let edit = document.getElementById('id-edit');
let editRect = edit.getBoundingClientRect();
let offset = [60, 60];
let xr;
let selection;

function city() {
    edit.innerHTML = `<div id="id-map" class="box-transform" style="width: 100%;height: 100%;background-color: rgb(7, 52, 68);"></div>`;
    var baseLayer = new maptalks.TileLayer('tile', {
        urlTemplate: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png',
        subdomains: ['a', 'b', 'c', 'd']
    });
    var map = new maptalks.Map("id-map", {
        center: [13.416935229170008, 52.529564137540376],
        zoom: 15.5,
        pitch: 85,
        baseLayer,
        // baseLayer: new maptalks.TileLayer('base', {
        //     urlTemplate: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
        //     subdomains: ['a','b','c','d'],
        //     attribution: '&copy; <a href="http://osm.org">OpenStreetMap</a> contributors, &copy; <a href="https://carto.com/">CARTO</a>'
        // })
    });
    var waterwayMaterial = new THREE.LineBasicMaterial({ color: 'rgb(255,90,0)', transparent: true, opacity: 1 });
    var roadMaterial = new THREE.LineBasicMaterial({ color: 0x00ffff, transparent: true, opacity: 0.1 });
    var buildMaterial = new THREE.MeshPhongMaterial({
        map: new THREE.TextureLoader().load('./images/build.png'),
        color: 0x00ffff,
        //specular: 0x222222,
        //shininess: 25,
        bumpMap: new THREE.TextureLoader().load('./images/build.png'),
        //bumpScale: 12,
        transparent: true
    });
    var vectortilelayer;
    var threeLayer = new maptalks.ThreeLayer('t');
    threeLayer.prepareToDraw = function (gl, scene, camera) {
        var light = new THREE.DirectionalLight(0xffffff);
        light.position.set(10, -10, 10).normalize();
        scene.add(light);

        //scene.add(new THREE.AmbientLight(0x000000));

        vectortilelayer = threeLayer.toThreeVectorTileLayer(
            `https://{s}.tiles.mapbox.com/v4/mapbox.mapbox-terrain-v2,mapbox.mapbox-streets-v7/{z}/{x}/{y}.vector.pbf?access_token=pk.eyJ1IjoiemhlbmZ1IiwiYSI6ImNpb284bzNoYzAwM3h1Ym02aHlrand6OTAifQ.sKX-XKJMmgtk_oI5oIUV_g`, 
            {
            // minZoom: 6,
            // maxZoom: 16,
            //debug: true,
            interactive: false,
            worker: true,
            subdomains: ['a', 'b', 'c', 'd'],
            // tileSize: [512, 512]
        }, function(layerName, data) {
            if(layerName === 'building') {
                return buildMaterial;
            } else if(layerName === 'road') {
                const type = data[0].geometry.type;
                if (type === 'LineString') {
                    return roadMaterial;
                } 
            } else if(layerName === 'waterway') {
                return waterwayMaterial;
            }
            return null;
        });
        vectortilelayer.getTileData = function (arg) {
            const { key, url, callback, img } = arg;
            let [id, y, x, z] = key.split('_');
            x = parseInt(x);
            y = parseInt(y);
            z = parseInt(z);

            fetch(url, {
                timeout: 10000,
                responseType: 'arraybuffer'
            })
            .then(response => response.arrayBuffer())
            .then(arraybuffer => {
                const geojson = mvt2GeoJSON(arraybuffer, x, y, z);
                callback(key, geojson, img);
            }).catch(error => {
                console.error(error);
                callback(key, null, img);
            }).finally(() => {

            });
        }
        map.addLayer(vectortilelayer);
        animation();
    }
    threeLayer.addTo(map);
    
    function animation() {
        if ((!map.isMoving()) && (!map.isZooming()) && (!map.isRotating())
         //&& (!params.rotate)
         ) {
            threeLayer._needsUpdate = !threeLayer._needsUpdate;
            if (threeLayer._needsUpdate) {
                threeLayer._renderer.clearCanvas();
                threeLayer.renderScene();
            }
        }
        map.setBearing(map.getBearing() + 0.1);
        requestAnimationFrame(animation);
    }
}

function init() {
    document.getElementById('id-city').onclick = e => {
        city();
    };
    xr = new Ruler({
        el: 'id-ruler',
        contain: editWrap,
        offsetX: offset[0],
        offsetY: offset[1]
    });
    selection = new Selection({
        el: 'id-selection',
        contain: editWrap,
        transform: `translate(${ offset[0] }, ${ offset[1] })`,
        dx: editRect.x,
        dy: editRect.y,
        validate: function() {
            if(this.current === editWrap || this.current === edit) {
                return true;
            }
        },
        onMouseMove: function() {
            editWrap.querySelectorAll('.box-transform').forEach(item => {
                let xy = item.style.transform.split(/[(|,|)]/g);
                let transform = edit.style.transform.split(/[(|,|)]/g), zoom = 1;
                if(transform && transform[1] !== undefined) {
                    zoom = transform[1];
                }
                if(Selection.rectsIntersect(this.currentRect, {
                    width: parseFloat(item.style.width, 10),
                    height: parseFloat(item.style.height, 10),
                    x: parseFloat(xy[1], 10),
                    y: parseFloat(xy[2], 10)
                }, zoom)) {
                    item.classList.add('box-transform-active');
                } else {
                    item.classList.remove('box-transform-active');
                }
            });
        },
        onMouseUp: function() {
            
        }
    });
}
function abc(dom, d) {
    let { x, y } = DragDrop.getPosByDom(dom);
    let box = {
        x,
        y,
        width: dom.offsetWidth,
        height: dom.offsetHeight
    };
    let list = editWrap.querySelectorAll('.box-transform'), rs = false;
    for(let i = 0; i < list.length; i++) {
        let item = list[i];
        if(!item.classList.contains('box-transform-active')) {
            let pos = DragDrop.getPosByDom(item);

            console.log(Math.abs(box.x - pos.x));

            // if(Math.abs(box.x - pos.x) <= d) {
            //     rs = {
            //         l: pos.x
            //     };
            //     break;
            // }
            // if(Math.abs(box.x - (pos.x + item.offsetWidth)) <= d) {
            //     rs = {
            //         l: pos.x + item.offsetWidth
            //     };
            //     break;
            // }

            // if(Math.abs(box.x + box.width - pos.x) <= d) {
            //     rs = {
            //         r: pos.x
            //     };
            //     break;
            // }
            // if(Math.abs(box.x + box.width - (pos.x + item.offsetWidth)) <= d) {
            //     rs = {
            //         r: pos.x + item.offsetWidth
            //     };
            //     break;
            // }

            // if(Math.abs(box.y - pos.y) <= d) {
            //     rs = {
            //         t: pos.y
            //     };
            //     break;
            // }
            // if(Math.abs(box.y - (pos.y + item.offsetHeight)) <= d) {
            //     rs = {
            //         t: pos.y + item.offsetHeight
            //     };
            //     break;
            // }

            // if(Math.abs(box.y + box.height - pos.y) <= d) {
            //     rs = {
            //         b: pos.y
            //     };
            //     break;
            // }
            // if(Math.abs(box.y + box.height - (pos.y + item.offsetHeight)) <= d) {
            //     rs = {
            //         b: pos.y + item.offsetHeight
            //     };
            //     break;
            // }
        }
    }
    return rs;
}
function resize(size) {
    let { width, height, scale } = size, nScale;
    edit.style.width = width + 'px';
    edit.style.height = height + 'px';
    if(scale === undefined) {
        nScale = ((editWrap.offsetWidth - 120) / width).toFixed(2);
        if(nScale > 1) {
            nScale = 1;
        }
    } else {
        nScale = scale;
    }
    edit.style.transform = `scale(${nScale})`;
    xr.refresh(nScale);
    editWrap.querySelectorAll('.box-transform').forEach(item => {
        item.addEventListener('click', e => {
            console.log(e);
            e.preventDefault();
        });
    });
}
function addComponents() {
    let arr = [{
        attr: {
            width: 568,
            height: 320,
            x: -18,
            y: 34
        }
    }, {
        attr: {
            width: 574,
            height: 345,
            x: 401,
            y: 465
        }
    }, {
        attr: {
            width: 409,
            height: 359,
            x: 1144,
            y: 124
        }
    }, {
        attr: {
            width: 593,
            height: 264,
            x: 1331,
            y: 719
        }
    }, {
        attr: {
            width: 414,
            height: 250,
            x: 524,
            y: 211
        }
    }, {
        attr: {
            width: 332,
            height: 199,
            x: 1088,
            y: 597
        }
    }], rs = [];
    for(let i = 0; i < arr.length; i++) {
        let attr = arr[i].attr;
        rs.push(
            `<div class="box-transform" style="width: ${ attr.width }px;height: ${ attr.height }px;transform: translate(${ attr.x }px, ${ attr.y }px);"></div>`
        );
    }
    edit.innerHTML = rs.join('');
    //DragDrop
    editWrap.querySelectorAll('.box-transform').forEach(item => {
        new DragDrop({
            el: item,
            onMouseDown: function() {
                // this.cache = [];
                // editWrap.querySelectorAll('.box-transform-active').forEach(sd => {
                //     if(this.current !== sd) {
                //         let { x, y } = DragDrop.getPosByDom(sd);
                //         this.cache.push({
                //             dom: sd,
                //             x,
                //             y
                //         });
                //     }
                // });
            },
            onMouseMove: function() {
                let rs = abc(this.el, 60);
                console.log(rs);
                // this.cache.forEach(sd => {
                //     let { dom, x, y } = sd;
                //     DragDrop.setPos(dom, [x + this.increaseX, y + this.increaseY]); 
                // });

                //this.moveLayer(layerBox);
                /*this.handle.style.top = parseInt(this.el.style.top, 10) + "px";
                this.handle.style.left = parseInt(this.el.style.left, 10) + "px";
                if (!this.gcmps) {
                let {gcmps} = Dldh.getData(this.el);
                this.gcmps = gcmps;
                }
                this.gcmps['x'].setValue(parseInt(this.el.style.left, 10));
                this.gcmps['y'].setValue(parseInt(this.el.style.top, 10));
                if (!this.oper) {
                this.oper = document.getElementById(this.el.getAttribute('operid'));
                }
                if (this.oper) {
                this.oper.style.top = (parseInt(this.el.style.top, 10) + 5) + 'px';
                this.oper.style.left = (parseInt(this.el.style.left, 10) + (parseInt(this.el.style.width, 10) - parseInt(this.oper.offsetWidth, 10)) - 3) + 'px';
                }*/
            },
            onMouseUp: function () {
              if (this.endPageX != this.startPageX || this.endPageY != this.startPageY) {
                //reqUpdateItem(this.el);
              }
            },
            handle: item
        });
        new Resizable({
            el: item
        });
    });
}
function main() {
    init();
    addComponents();
    resize({
        width: 1920,
        height: 1028
    });
    window.onresize = function() {
        resize({
            width: 1920,
            height: 1028
        });
    }
}
main();