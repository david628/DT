import * as THREE from 'three';
import { RenderPass } from './libs/jsm/postprocessing/RenderPass';
import { UnrealBloomPass } from './libs/jsm/postprocessing/UnrealBloomPass';
import { EffectComposer } from './libs/jsm/postprocessing/EffectComposer.js';
import { OrbitControls } from './libs/OrbitControls';


class Bloom {
    constructor(props) {
        this.ENTIRE_SCENE = 0;
        this.BLOOM_SCENE = 1;
        Object.assign(this, props);
        this.animate = this.animate.bind(this);
        this.init();
    }
    init() { 
        this.el = document.getElementById(this.el);
        let w = this.el.offsetWidth,
            h = this.el.offsetHeight;
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(75, w / h, 1, 1000);
        this.camera.position.set(0, 0, 10);

        this.renderer = new THREE.WebGLRenderer();
        this.renderer.setSize(w, h);
        this.el.appendChild(this.renderer.domElement);

        this.scene.add(new THREE.AxesHelper(300));

        let point = new THREE.PointLight(0xffffff);
        point.position.set(400, 200, 300); //点光源位置
        this.scene.add(point); //点光源添加到场景中

        this.controls = new OrbitControls(this.camera, this.renderer.domElement);

        this.bloomLayer = new THREE.Layers();
        this.bloomLayer.set(this.BLOOM_SCENE);
        this.darkMaterial = new THREE.MeshBasicMaterial({color: "black"});
		this.materials = {};

        this.addLine();
        this.addLine1();
        this.addBox();

        let params = {
            //exposure: 1,
            bloomStrength: 2,
            bloomThreshold: 0,
            bloomRadius: 0,
        };

        let renderScene = new RenderPass(this.scene, this.camera);
        let bloomPass = new UnrealBloomPass(new THREE.Vector2(w, h));
        bloomPass.threshold = params.bloomThreshold;
        bloomPass.strength = params.bloomStrength;
        bloomPass.radius = params.bloomRadius;

        let bloomComposer = new EffectComposer(this.renderer);
        //bloomComposer.renderToScreen = false;
        bloomComposer.addPass(renderScene);
        bloomComposer.addPass(bloomPass);

        this.bloomComposer = bloomComposer;

        // this.composer = new THREE.EffectComposer(this.renderer);
        // this.composer.setSize(w, h);
        // this.renderPass = new THREE.RenderPass(this.scene, this.camera);
        // let bloomPass = new THREE.BloomPass(3, 25, 5.0, 256);
        // this.composer.addPass(this.renderPass);
        // this.composer.addPass(bloomPass);
        // bloomPass.renderToScreen = true;
        
        //const bloomPass = this.bloomPass = new THREE.UnrealBloomPass(new THREE.Vector2(size.width, size.height));
        
        //bloomPass.threshold = params.bloomThreshold;
        //bloomPass.strength = params.bloomStrength;
        //bloomPass.radius = params.bloomRadius;

        // composer.setSize(size.width, size.height);
        // composer.addPass(renderPass);
        // this.composer.addPass(bloomPass);

    }
    darkenNonBloomed(obj) {
        if (obj.isMesh && this.bloomLayer.test(obj.layers) === false) {
            this.materials[obj.uuid] = obj.material;
            obj.material = darkMaterial;
        }
    }
    restoreMaterial(obj) {
        if (this.materials[obj.uuid]) {
            obj.material = materials[obj.uuid];
            delete this.materials[obj.uuid];
        }
    }
    addBox() {
        let geometry = new THREE.BoxGeometry(1, 1, 1);
        let material = new THREE.MeshBasicMaterial({color: 0x00ff00});
        let box = new THREE.Mesh(geometry, material);
        this.scene.add(box);
    }
    addLine1() {
        let path = [
            new THREE.Vector3(-5, 0, 0),
            new THREE.Vector3(0, 5, 0),
            new THREE.Vector3(10, 0, 0)
        ];
        let spline = new THREE.CatmullRomCurve3(path);
        let points = spline.getPoints(100);
        let tubeGeometry = new THREE.TubeGeometry(spline, 100, 0.03, 10, false);
        let tubeMaterial = new THREE.MeshPhongMaterial({
            color: 0xffffff,
            transparent: true,
            opacity: 0.3,
        });
        let tube = new THREE.Mesh(tubeGeometry, tubeMaterial);
        tube.position.y = -2;
        this.scene.add(tube);
    }
    addLine() {
        // let geometry = new THREE.BoxGeometry(10, 10, 1);
        // let material = new THREE.MeshBasicMaterial({color: 0x00ff00});
        // let cube = new THREE.Mesh(geometry, material);
        // this.scene.add(cube);
        // return false;
        let path = [
            new THREE.Vector3(-5, 0, 0),
            new THREE.Vector3(0, 5, 0),
            new THREE.Vector3(10, 0, 0)
        ];
        let spline = new THREE.CatmullRomCurve3(path);
        let points = spline.getPoints(100);

        // var curve = new THREE.CatmullRomCurve3([
        //     new THREE.Vector3(-80, -40, 0),
        //     new THREE.Vector3(-70, 40, 0),
        //     new THREE.Vector3(70, 40, 0),
        //     new THREE.Vector3(80, -40, 0)
        // ],false/*是否闭合*/);
        // var tubeGeometry = new THREE.TubeGeometry(curve, 100, 0.6, 50, false);
        // var tubeMaterial = new THREE.MeshPhongMaterial({
        //     color: 0xffffff,
        //     //map: texture,
        //     //transparent: true,
        // });
        // var tube = new THREE.Mesh(tubeGeometry, tubeMaterial);
        // this.scene.add(tube);
        // return false;

        let positions = [];
        let colors = [];
        let color = new THREE.Color();
        
        for(let i = 0; i < points.length; i++) {
            positions.push(points[i].x, points[i].y, points[i].z);
            color.setHSL(i / 10, 1.0, 0.5);
            colors.push(color.r, color.g, color.b);
        }

        // let matLine = new LineMaterial({
        //     //color: 0xffffff,
        //     linewidth: 300, // in pixels
        //     vertexColors: THREE.VertexColors,
        //     //resolution:  // to be set by renderer, eventually
        //     //dashed: false
        // });
        // let geo = new LineGeometry();
        // geo.setPositions(positions);
        // geo.setColors(colors);
        
        let matLine = new THREE.LineBasicMaterial({
            //color: 0xffffff,
            gapSize: 10,
            linewidth: 300, // in pixels
            vertexColors: THREE.VertexColors,
            //resolution:  // to be set by renderer, eventually
            //dashed: false
        });

        let geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
		geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
        //let matLineBasic = new THREE.LineBasicMaterial({vertexColors: THREE.VertexColors});
        let line = new THREE.Line(geo, matLine);
        line.layers.set(this.BLOOM_SCENE);
        this.scene.add(line);
    }
    animate() {
        requestAnimationFrame(this.animate);
        //this.renderer.render(this.scene, this.camera);
        this.bloomComposer.render();
        this.scene.traverse((obj) => {
            if (obj.isMesh && this.bloomLayer.test(obj.layers) === false) {
                this.materials[obj.uuid] = obj.material;
                obj.material = this.darkMaterial;
            }
        });
        this.scene.traverse((obj) => {
            if (this.materials[obj.uuid]) {
                obj.material = this.materials[obj.uuid];
                delete this.materials[obj.uuid];
            }
        });
        this.controls.update();
        //this.renderer.toneMappingExposure = Math.pow(1, 4.0);
    }
    
}

var cy = new Bloom({
    el: 'id-test'
});
cy.animate();
