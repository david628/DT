import './index.less';
export default class Selection {
    constructor(props) {
        this.tp = `
            <svg class="selection">
                <rect stroke-dasharray="3,2" style="pointer-events:none"></rect>
            </svg>
        `;
        this.attr = {
            fill: 'none',
            stroke: '#666',
            //strokeDasharray: '3,2',
            display: 'inline',
            x: 0,
            y: 0,
            width: 0,
            height: 0
        };
        this.startX = 0;
        this.startY = 0;
        this.endX = 0;
        this.endY = 0;
        Object.assign(this, props);
        if(this.transform !== undefined) {
            this.attr.transform = this.transform;
        }
        this.contain = this.contain.get ? this.contain.get(0) : (typeof this.contain == "string" ? document.getElementById(this.contain) : this.contain);
        this.el = this.el.get ? this.el.get(0) : (typeof this.el == "string" ? document.getElementById(this.el) : this.el);
        this.el.innerHTML = this.tp;
        this.svg = this.el.querySelector('svg');
        this.rect = this.el.querySelector('rect');
        this.setAttr(this.attr);
        var onMouseMove = (e) => {
            this.endX = e.pageX;
            this.endY = e.pageY;
            let x = this.startX - this.dx + this.contain.scrollLeft, 
                y = this.startY - this.dy + this.contain.scrollTop, 
            width = Math.abs(this.endX - this.startX),
            height = Math.abs(this.endY - this.startY);
            if(this.endX - this.startX < 0) {
                x = x - width;
            }
            if(this.endY - this.startY < 0) {
                y = y - height;
            }
            this.currentRect = {
                x,
                y,
                width,
                height
            }
            this.setAttr(this.currentRect);
            this.onMouseMove();
        }
        var onMouseUp = (e) => {
            this.setAttr({
                width: 0,
                height: 0
            });
            this.contain.removeEventListener('mousemove', onMouseMove);
            this.contain.removeEventListener('mouseup', onMouseUp);
            this.onMouseUp();
        }
        var onMouseDown = (e) => {
            e.preventDefault();
            if(e.button === 2) {
                return;
            }
            this.current = e.target;
            if(!this.validate()) {
                return;
            }
            let containRect = this.contain.getBoundingClientRect();
            this.svg.style.width = (containRect.width + this.contain.scrollLeft) + 'px';
            this.svg.style.height = (containRect.height + this.contain.scrollTop) + 'px';
            this.startX = e.pageX;
            this.startY = e.pageY;
            //console.log(this.rect.getScreenCTM().inverse());
            this.contain.addEventListener('mousemove', onMouseMove, false);
            this.contain.addEventListener('mouseup', onMouseUp, false);
            this.onMouseDown();
        }
        this.contain.addEventListener('mousedown', onMouseDown, false);
        this.init();
        //this.hide();
    }
    init() {}
    setAttr(opt) {
        for(let key in opt) {
            this.rect.setAttribute(key, opt[key]);
        }
    }
    static rectsIntersect(r1, r2, zoom) {
        if(!r1 || !r2) {
            return false;
        }
        let scale = zoom || 1;
        return r2.x < (r1.x / scale + r1.width / scale) 
            && (r2.x + r2.width) > r1.x / scale 
            && r2.y < (r1.y / scale + r1.height / scale) 
            && (r2.y + r2.height) > r1.y / scale;
    }
    validate(e) {
        return true;
    }
    onMouseDown() {}
    onMouseMove() {}
    onMouseUp() {}
}