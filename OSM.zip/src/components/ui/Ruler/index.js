import './index.less';
export default class Ruler {
    constructor(props) {
        this.tp = `
            <div class="ruler" style="position: relative;width: 100%;height: 100%;">
                <div class="ruler-x" style="position: absolute;left: 0;top: 0;height: 18px;overflow: hidden;background: #000;"></div>
                <div class="ruler-y" style="position: absolute;left: 0;top: 0;width: 18px;overflow: hidden;background: #000;"></div>
            </div>
        `;
        this.offsetX = 80;
        this.offsetY = 80;
        this.fontColor = '#999';
        Object.assign(this, props);
        this.intervals = [];
        for(let i = .1; i < 1E5; i *= 10) {
            this.intervals.push(1 * i);
            this.intervals.push(2 * i);
            this.intervals.push(5 * i);
        }
        this.contain = this.contain.get ? this.contain.get(0) : (typeof this.contain == "string" ? document.getElementById(this.contain) : this.contain);
        this.el = this.el.get ? this.el.get(0) : (typeof this.el == "string" ? document.getElementById(this.el) : this.el);
        this.el.innerHTML = this.tp;
        let canvasX = document.createElement('canvas');
        let rulerX = this.el.querySelector('.ruler-x');
        rulerX.appendChild(canvasX);
        rulerX.style.paddingLeft = this.offsetX + 'px';

        let canvasY = document.createElement('canvas');
        let rulerY = this.el.querySelector('.ruler-y');
        rulerY.appendChild(canvasY);
        rulerY.style.paddingTop = this.offsetY + 'px';
        this.canvas = [canvasX, canvasY];

        this.init();
    }
    init() {}
    refresh(zoom, size) {
        this.updateRule(zoom, 'x', size);
        this.updateRule(zoom, 'y', size);
    }
    updateRule(zoom, type, rect) {
        let size = Object.assign({
                width: this.contain.offsetWidth - this.offsetX,
                height: this.contain.offsetHeight - this.offsetY - 4
            }, rect),
            left = 0,
            //offset_x = 0,
            //offset_y = 0,
            unit = 1,
            lentype = type === 'x' ? 'width' : 'height',
            content_d = left - 0,
            limit = 30000,
            ruler_len = size[lentype],
            total_len = ruler_len,
            canv_count = 1,
            ctx_num = 0,
            ctx_arr,
            canvas = type === 'x' ? this.canvas[0] : this.canvas[1],
            ctx = canvas.getContext("2d");
            canvas.style[lentype] = total_len + 'px';
        ctx.fillStyle = "rgb(200,0,0)";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        if (ruler_len >= limit) {
            let num = parseInt(ruler_len / limit, 10) + 1;
            ctx_arr = Array(num);
            ctx_arr[0] = ctx;
            for (let i = 1; i < num; i++) {
                canvas[lentype] = limit;
                ctx_arr[i] = ctx;
            }
            ctx[lentype] = ruler_len % limit;
            ruler_len = limit;
        }
        canvas[lentype] = ruler_len;

        let u_multi = unit * zoom,
            raw_m = 50 / u_multi,
            multi = 1;
        for (let i = 0; i < this.intervals.length; i++) {
            let num = this.intervals[i];
            multi = num;
            if (raw_m <= num) {
                break;
            }
        }

        let big_int = multi * u_multi;
        ctx.font = "normal 9px 'Lucida Grande', sans-serif";
        ctx.fillStyle = this.fontColor;

        let ruler_d = ((content_d / u_multi) % multi) * u_multi, label_pos = ruler_d - big_int;

        for (; ruler_d < total_len; ruler_d += big_int) {
            label_pos += big_int;
            let real_d = ruler_d - content_d,
            cur_d = Math.round(ruler_d) + .5;
            if (type === 'x') {
                ctx.moveTo(cur_d, 15);
                ctx.lineTo(cur_d, 0);
            } else {
                ctx.moveTo(15, cur_d);
                ctx.lineTo(0, cur_d);
            }
            let num = (label_pos - content_d) / u_multi, label;
            if (multi >= 1) {
                label = Math.round(num);
            } else {
                let decs = (multi + '').split('.')[1].length;
                label = num.toFixed(decs) - 0;
            }

            if (label !== 0 && label !== 1000 && label % 1000 === 0) {
                label = (label / 1000) + 'K';
            }
            //if(label >= 0) {
                if (type === 'x') {
                    ctx.fillText(label, ruler_d + 2, 8);
                    ctx.fillStyle = this.fontColor;
                } else {
                    let str = (label + '').split('');
                    for (let i = 0; i < str.length; i++) {
                        ctx.fillText(str[i], 1, (ruler_d + 9) + i * 9);
                        ctx.fillStyle = this.fontColor;
                    }
                }
            //}
            

            let part = big_int / 10;
            for (let i = 1; i < 10; i++) {
                let sub_d = Math.round(ruler_d + part * i) + .5;
                if (ctx_arr && sub_d > ruler_len) {
                    ctx_num++;
                    ctx.stroke();
                    if (ctx_num >= ctx_arr.length) {
                        i = 10;
                        ruler_d = total_len;
                        continue;
                    }
                    ctx = ctx_arr[ctx_num];
                    ruler_d -= limit;

                    sub_d = Math.round(ruler_d + part * i) + .5;
                }

                let line_num = (i % 2) ? 12 : 10;                
                if (type === 'x') {
                    ctx.moveTo(sub_d, 15);
                    ctx.lineTo(sub_d, line_num);
                } else {
                    ctx.moveTo(15, sub_d);
                    ctx.lineTo(line_num, sub_d);
                }
            }
        }
        ctx.strokeStyle = this.fontColor;
        ctx.stroke();
    }
}