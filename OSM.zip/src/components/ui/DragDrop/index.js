import './index.less';
export default class DragDrop {
    constructor(props) {
        this.startPageX = 0;
        this.startPageY = 0;
        this.endPageX = 0;
        this.endPageY = 0;
        this.startX = 0;
        this.startY = 0;
        this.endX = 0;
        this.endY = 0;
        Object.assign(this, props);
        this.handleMouseDown = this.handleMouseDown.bind(this);
        this.handleMouseMove = this.handleMouseMove.bind(this);
        this.handleMouseUp = this.handleMouseUp.bind(this);
        this.el = this.getDom(this.el);
        if(this.handle) {
            this.handle = this.getDom(this.handle);
        } else {
            this.handle = this.el;
        }
        this.handle.addEventListener('mousedown', this.handleMouseDown, false);
    }
    init() {}
    getDom(el) {
        if(el === undefined) {
            return null;
        }
        return el.get ? el.get(0) : (typeof el == "string" ? document.getElementById(el) : el);
    }
    getStyle(el, style) {
        let dom = this.getDom(el);
        if(dom.currentStyle) {
            return dom.currentStyle[style];
        } else {
            return window.getComputedStyle(dom, null)[style];
        }
    }
    handleMouseDown(e) {
        if(e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
        if(e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        if(e.button != 0 && e.button != 1) {
            return;
        }
        this.current = e.target;
        let { x, y } = DragDrop.getPosByDom(this.el);
        this.startPageX = this.endPageX = x;
        this.startPageY = this.endPageY = y;
        this.startX = e.pageX;
        this.startY = e.pageY;
        //this.increaseX = this.startX - this.startPageX;
        //this.increaseY = this.startY - this.startPageY;
        this.unlock();
        document.addEventListener('mousemove', this.handleMouseMove, false);
        document.addEventListener('mouseup', this.handleMouseUp, false);
        this.onMouseDown();
    }
    handleMouseMove(e) {
        if(e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
        if(e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        if(this.isLocked()) {
            return;
        }
        this.endX = e.pageX;
        this.endY = e.pageY;

        let scale = this.getScale(), g = 10;

        this.increaseX = Math.round((this.endX - this.startX) / g / scale) * g;
        this.increaseY = Math.round((this.endY - this.startY) / g / scale) * g;

        this.endPageX = this.startPageX + this.increaseX;
        this.endPageY = this.startPageY + this.increaseY;

        this.moveTo([this.endPageX, this.endPageY]);

        
        //this.increaseX = parseInt((this.endX - this.startX) * (1 / scale), 10);
        //this.increaseY = parseInt((this.endY - this.startY) * (1 / scale), 10);
        // if((this.endX - this.startX) % 20 === 0 || (this.endY - this.startY) % 20 === 0) {
        //     let scale = this.getScale();
        //     this.increaseX = (this.endX - this.startX) * (1 / scale);
        //     this.increaseY = (this.endY - this.startY) * (1 / scale);

        //     this.increaseX = parseInt(this.increaseX, 10);
        //     this.increaseY = parseInt(this.increaseY, 10);

        //     this.endPageX = this.startPageX + this.increaseX;
        //     this.endPageY = this.startPageY + this.increaseY;

        //     console.log(this.endPageX, this.endPageY);
        //     DragDrop.setPos(this.el, [this.endPageX, this.endPageY]);
        // }
        this.onMouseMove();
    }
    handleMouseUp(e) {
        if(e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
        if(e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        this.lock();
        document.removeEventListener('mousemove', this.handleMouseMove);
        document.removeEventListener('mouseup', this.handleMouseUp);
        this.onMouseUp();
    }
    moveTo(pos) {
        DragDrop.setPos(this.el, pos);
    }
    getScale() {
        let edit = document.getElementById('id-edit');
        let transform = edit.style.transform.split(/[(|,|)]/g), zoom = 1;
        if(transform && transform[1] !== undefined) {
            zoom = transform[1];
        }
        return zoom;
    }
    static getPosByDom(dom) {
        let xy = dom.style.transform.split(/[(|,|)]/g);
        return {
            x: parseFloat(xy[1], 10),
            y: parseFloat(xy[2], 10)
        };
    }
    static setPos(dom, pos) {
        dom.style.transform = `translate(${ pos[0] }px, ${ pos[1] }px)`;
        //dom.style.left = pos[0] + 'px';
        //dom.style.top = pos[1] + 'px';
    }
    showDrag() {
        this.drag.style.visibility = "visible";
    }
    hideDrag() {
        this.drag.style.visibility = "hidden";
    }
    lock() {
        this.locked = true;
    }
    unlock() {
        this.locked = false;
    }
    isLocked() {
        return this.locked;
    }
    onMouseDown() {}
    onMouseMove() {}
    onMouseUp() {}
}