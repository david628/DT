import './index.less';
export default class Resizable {
    constructor(props) {
        this.height = null;
        this.width = null;
        this.heightIncrement = 0;
        this.widthIncrement = 0;
        this.minHeight = 5;
        this.minWidth = 5;
        this.maxHeight = 10000;
        this.maxWidth = 10000;
        this.minX = 0;
        this.minY = 0;
        this.handles = 'all';
        this.multiDirectional = false;
        this.positions = {
            n: "north",
            s: "south",
            e: "east",
            w: "west",
            se: "southeast",
            sw: "southwest",
            nw: "northwest",
            ne: "northeast"
        }
        this.pos = null;
        this.preserveRatio = false;
        Object.assign(this, props);
        this.handleMouseDown = this.handleMouseDown.bind(this);
        this.handleMouseMove = this.handleMouseMove.bind(this);
        this.handleMouseUp = this.handleMouseUp.bind(this);
        if (!this.handles) {
            this.handles = "s,e,se";
            if (this.multiDirectional) {
                this.handles += ",n,w";
            }
        }
        if (this.handles == "all") {
            this.handles = "n s e w ne nw se sw";
        }
        let o = this.handles.split(/\s*?[,;]\s*?| /);
        for (let j = 0, l = o.length; j < l; j++) {
            if (o[j] && this.positions[o[j]]) {
                var n = this.positions[o[j]];
                this[n] = this.createHandle(n);
            }
        }
        this.corner = this.southeast;
        if (this.handles.indexOf("n") != -1 || this.handles.indexOf("w") != -1) {
            this.updateBox = true;
        }
        if (navigator.userAgent.toLowerCase().indexOf("msie") > -1) {
            this.el.style.zoom = 1;
        }
    }
    init() { }
    getDom(el) {
        if (el === undefined) {
            return null;
        }
        return el.get ? el.get(0) : (typeof el == "string" ? document.getElementById(el) : el);
    }
    getStyle(el, style) {
        let dom = this.getDom(el);
        if (dom.currentStyle) {
            return dom.currentStyle[style];
        } else {
            return window.getComputedStyle(dom, null)[style];
        }
    }
    createHandle(pos) {
        let hl = document.createElement("div");
        hl.className = "resizable-handle resizable-handle-" + pos;
        hl.style['-moz-user-select'] = 'none';
        hl.style['-khtml-user-select'] = 'none';
        hl.style['user-select'] = 'none';
        hl.style['-webkit-user-select'] = 'ignore';
        hl.setAttribute('pos', pos);
        this.el.appendChild(hl);
        hl.addEventListener('mousedown', this.handleMouseDown, false);
    }
    handleMouseDown(e) {
        if(e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
        if(e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        this.current = e.target;
        this.pos = this.current.getAttribute('pos');
        if (!this.overlay) {
            this.overlay = document.createElement("div");
            this.overlay.className = "resizable-overlay";
            this.overlay.innerHtml = "&#160;";
            document.body.appendChild(this.overlay);
            this.overlay.style['-moz-user-select'] = 'none';
            this.overlay.style['-khtml-user-select'] = 'none';
            this.overlay.style['user-select'] = 'none';
            this.overlay.style['-webkit-user-select'] = 'ignore';
            this.overlay.style.display = 'none';
            this.overlay.addEventListener('mousemove', this.handleMouseMove, false);
            this.overlay.addEventListener('mouseup', this.handleMouseUp, false);
        }
        this.overlay.style.display = 'block';
        this.resizing = true;
        let { x, y } = Resizable.getPosByDom(this.el);
        this.startBox = {
            width: parseFloat(this.el.style.width, 10),
            height: parseFloat(this.el.style.height, 10),
            x,
            y
        };
        this.endBox = this.startBox;
        this.startPoint = [e.pageX, e.pageY];
        this.onMouseDown();
    }
    handleMouseMove(e) {
        if(e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
        if(e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        this.resizeMove(e);
        this.onMouseMove();
    }
    handleMouseUp(e) {
        if(e.preventDefault) {
            e.preventDefault();
        } else {
            e.returnValue = false;
        }
        if(e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
        this.resizing = false;
        this.overlay.style.display = 'none';
        this.onMouseUp();
    }
    resizeElement() {
        // let scale = this.getScale(), g = 10;

        // this.increaseX = Math.round((this.endX - this.startX) / g / scale) * g;
        // this.increaseY = Math.round((this.endY - this.startY) / g / scale) * g;

        let { width, height, x, y } = this.endBox;
        this.el.style.width = width + 'px';
        this.el.style.height = height + 'px';
        this.el.style.transform = `translate(${x}px, ${y}px)`;
    }
    resizeMove(e) {
        if (this.resizing && this.pos) {
            let t = this.curSize || this.startBox,
                l = this.startBox.x,
                k = this.startBox.y,
                c = l,
                b = k,
                m = t.width,
                u = t.height,
                d = m,
                o = u,
                n = this.minWidth,
                A = this.minHeight,
                s = this.maxWidth,
                D = this.maxHeight,
                i = this.widthIncrement,
                a = this.heightIncrement,
                B = [e.pageX, e.pageY],
                //r = -(this.startPoint[0] - Math.max(this.minX, B[0])),
                //p = -(this.startPoint[1] - Math.max(this.minY, B[1])),
                bei = 10,
                scale = this.getScale(),
                r = -Math.round((this.startPoint[0] - B[0]) / bei / scale) * bei,
                p = -Math.round((this.startPoint[1] - B[1]) / bei / scale) * bei,
                j = this.pos, E, g;
            switch (j) {
                case "east":
                    m += r;
                    m = Math.min(Math.max(n, m), s);
                    break;
                case "south":
                    u += p;
                    u = Math.min(Math.max(A, u), D);
                    break;
                case "southeast":
                    m += r;
                    u += p;
                    m = Math.min(Math.max(n, m), s);
                    u = Math.min(Math.max(A, u), D);
                    break;
                case "north":
                    p = this.constrain(u, p, A, D);
                    k += p;
                    u -= p;
                    break;
                case "west":
                    r = this.constrain(m, r, n, s);
                    l += r;
                    m -= r;
                    break;
                case "northeast":
                    m += r;
                    m = Math.min(Math.max(n, m), s);
                    p = this.constrain(u, p, A, D);
                    k += p;
                    u -= p;
                    break;
                case "northwest":
                    r = this.constrain(m, r, n, s);
                    p = this.constrain(u, p, A, D);
                    k += p;
                    u -= p;
                    l += r;
                    m -= r;
                    break;
                case "southwest":
                    r = this.constrain(m, r, n, s);
                    u += p;
                    u = Math.min(Math.max(A, u), D);
                    l += r;
                    m -= r;
                    break
            }
            var q = this.snap(m, i, n);
            var C = this.snap(u, a, A);
            if (q != m || C != u) {
                switch (j) {
                    case "northeast":
                        k -= C - u;
                        break;
                    case "north":
                        k -= C - u;
                        break;
                    case "southwest":
                        l -= q - m;
                        break;
                    case "west":
                        l -= q - m;
                        break;
                    case "northwest":
                        l -= q - m;
                        k -= C - u;
                        break
                }
                m = q;
                u = C
            }
            if (this.preserveRatio) {
                switch (j) {
                    case "southeast":
                    case "east":
                        u = o * (m / d);
                        u = Math.min(Math.max(A, u), D);
                        m = d * (u / o);
                        break;
                    case "south":
                        m = d * (u / o);
                        m = Math.min(Math.max(n, m), s);
                        u = o * (m / d);
                        break;
                    case "northeast":
                        m = d * (u / o);
                        m = Math.min(Math.max(n, m), s);
                        u = o * (m / d);
                        break;
                    case "north":
                        E = m;
                        m = d * (u / o);
                        m = Math.min(Math.max(n, m), s);
                        u = o * (m / d);
                        l += (E - m) / 2;
                        break;
                    case "southwest":
                        u = o * (m / d);
                        u = Math.min(Math.max(A, u), D);
                        E = m;
                        m = d * (u / o);
                        l += E - m;
                        break;
                    case "west":
                        g = u;
                        u = o * (m / d);
                        u = Math.min(Math.max(A, u), D);
                        k += (g - u) / 2;
                        E = m;
                        m = d * (u / o);
                        l += E - m;
                        break;
                    case "northwest":
                        E = m;
                        g = u;
                        u = o * (m / d);
                        u = Math.min(Math.max(A, u), D);
                        m = d * (u / o);
                        k += g - u;
                        l += E - m;
                        break
                }
            }
            this.endBox = {
                x: l,
                y: k,
                width: m,
                height: u
            };
            this.resizeElement();
            this.onMouseMove();
        }
    }
    getScale() {
        let edit = document.getElementById('id-edit');
        let transform = edit.style.transform.split(/[(|,|)]/g), zoom = 1;
        if(transform && transform[1] !== undefined) {
            zoom = transform[1];
        }
        return zoom;
    }
    constrain(b, c, a, d) {
        if (b - c < a) {
            c = b - a;
        } else {
            if (b - c > d) {
                c = b - d;
            }
        }
        return c;
    }
    snap(c, e, b) {
        if (!e || !c) {
            return c
        }
        let d = c, a = c % e;
        if (a > 0) {
            if (a > (e / 2)) {
                d = c + (e - a)
            } else {
                d = c - a
            }
        }
        return Math.max(b, d);
    }
    static getPosByDom(dom) {
        let xy = dom.style.transform.split(/[(|,|)]/g);
        return {
            x: parseFloat(xy[1], 10),
            y: parseFloat(xy[2], 10)
        };
    }
    onMouseDown() { }
    onMouseMove() { }
    onMouseUp() { }
}