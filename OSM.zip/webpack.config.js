const path = require('path');
const webpack = require('webpack');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const HtmlWebpackPlugin = require('html-webpack-plugin');

// Is the current build a development build
const IS_DEV = (process.env.NODE_ENV === 'dev');

const dirNode = 'node_modules';
const dirApp = path.join(__dirname, './src');
const dirAssets = path.join(__dirname, './src/assets');

const appHtmlTitle = 'Data View';
/**
 * Webpack Configuration
 */
module.exports = {
  entry: {
    vendor: ['lodash'],
    index: path.join(dirApp, 'index'),
    screen: path.join(dirApp, 'screen'),
    city: path.join(dirApp, 'city'),
    bloom: path.join(dirApp, 'bloom'),
  },
  resolve: {
    modules: [
      dirNode,
      dirApp,
      dirAssets
    ]
  },
  devServer: {
    compress: true,
    proxy: {
      "/lib/": {
        target: "http://localhost:8080/webapp",
        secure: false
      },
      "/i18n/": {
        target: "http://localhost:8080/webapp",
        secure: false
      },
      "/images/": {
        target: "http://localhost:8080/webapp",
        secure: false
      },
      "/app": {
        target: "http://127.0.0.1:3100",
        pathRewrite: {'^/app/': ''},
        changeOrigin: true,
        secure: false
      }
      /*"/": {
        target: "http://183.129.170.220:8088",
        pathRewrite: {'^/dlv/': ''},
        changeOrigin: true,
        secure: false
      }*/
    }
  },
  plugins: [
    /*new webpack.ProvidePlugin({
        "$": "jquery",
        "jQuery": "jquery",
        "window.jQuery": "jquery"
    }),*/
    new webpack.DefinePlugin({
      IS_DEV: IS_DEV
    }),
    new MiniCssExtractPlugin({
      // Options similar to the same options in webpackOptions.output
      // both options are optional
      filename: "static/css/[name].[contenthash].css",
      chunkFilename: "static/css/[id].css"
    }),
    new HtmlWebpackPlugin({
      //favicon: './src/assets/images/favicon.ico',
      template: path.join(__dirname, 'index.ejs'),
      title: appHtmlTitle,
      chunks: ['vendor', 'index'],
      filename: "index.html"
    }),
    new HtmlWebpackPlugin({
      //favicon: './src/assets/images/favicon.ico',
      template: path.join(__dirname, 'screen.ejs'),
      title: appHtmlTitle,
      chunks: ['vendor', 'screen'],
      filename: "screen.html"
    }),
    new HtmlWebpackPlugin({
      //favicon: './src/assets/images/favicon.ico',
      template: path.join(__dirname, 'city.ejs'),
      title: appHtmlTitle,
      chunks: ['vendor', 'city'],
      filename: "city.html"
    }),
    new HtmlWebpackPlugin({
      //favicon: './src/assets/images/favicon.ico',
      template: path.join(__dirname, 'bloom.ejs'),
      title: appHtmlTitle,
      chunks: ['vendor', 'bloom'],
      filename: "bloom.html"
    })
  ],
  module: {
    rules: [{
      test: /\.js$/,
      loader: 'babel-loader',
      exclude: /(node_modules)/,
      options: {
        compact: true
      }
    }, {
      test: /\.css$/,
      use: [
        'style-loader',
        {
          loader: 'css-loader',
          options: {
            sourceMap: IS_DEV
          }
        }
      ]
    }, {
      test: /\.(scss|less)$/,
      use: [
        'style-loader',
        MiniCssExtractPlugin.loader,
        {
          loader: 'css-loader',
          options: {
            sourceMap: IS_DEV
          }
        }/*, {
          loader: 'sass-loader',
          options: {
            sourceMap: IS_DEV,
            includePaths: [dirAssets]
          }
        }*/, {  
          loader: 'less-loader',
          options: {
            sourceMap: IS_DEV,
            includePaths: [dirAssets],
            javascriptEnabled: true
          }
        }
      ]
    }, {
      test: /\.(jpe?g|png|gif|cur)$/,
      loader: 'file-loader',
      options: {
        name: '[path][name].[ext]',
        publicPath: '../../'
      }
    }/*, {
      test: /\.txt$/,
      use: 'raw-loader'
    }*/]
  }
};